# Test Confluent for Kubernetes  with Confluent Cloud

Quickly test [Confluent for Kubernetes ](https://docs.confluent.io/operator/current/co-quickstart.html#co-long-quickstart) with Confluent Cloud

See https://github.com/confluentinc/confluent-kubernetes-examples/tree/master/hybrid/ccloud-integration

