# Confluent Cloud

## Description

This is a deployment bootstrapped to Confluent Cloud:

* 1 connect
* 1 control-center

## Prerequisites

See [here](https://kafka-docker-playground.io/#/how-to-use?id=%f0%9f%8c%a4%ef%b8%8f-confluent-cloud-examples)

## How to run

Simply run:

```
$ just use <playground run> command and search for start.sh in this folder
```