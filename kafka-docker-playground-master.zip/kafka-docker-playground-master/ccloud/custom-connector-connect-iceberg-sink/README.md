# Custom Connector Apache Iceberg Sink Connector connector



## Objective

Quickly test [Apache Iceberg Sink Connector](https://github.com/tabular-io/iceberg-kafka-connect?tab=readme-ov-file) connector.




## How to run

Simply run:

```
$ just use <playground run> command 
```

You can open the jupyter lab at http://localhost:8888/lab/tree/notebooks and use the sample notebook to query the table

Refer to docker-spark-iceberg to check more details about it